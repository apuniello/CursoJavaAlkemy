package com.alkemy.tpinte1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tpinte1Application {

	public static void main(String[] args) {
		SpringApplication.run(Tpinte1Application.class, args);
	}

}
